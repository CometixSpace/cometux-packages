/// @file
/// @ingroup gvc_api
/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct GVCOMMON_s {
  char **info;
  char *cmdname;
  int verbose;
  bool config, auto_outfile_names;
  void (*errorfn)(const char *fmt, ...);
  const char **show_boxes; ///< emit code for correct box coordinates
  const char **lib;

  /// rendering state
  int viewNum; ///< current view - 1 based count of views, all pages in all
               ///< layers
  const lt_symlist_t *builtins;
  int demand_loading;
} GVCOMMON_t;

#ifdef __cplusplus
}
#endif
