##
## This script is sourced by /data/data/dev.cometix.cometux/files/usr/bin/login before executing shell.
##
