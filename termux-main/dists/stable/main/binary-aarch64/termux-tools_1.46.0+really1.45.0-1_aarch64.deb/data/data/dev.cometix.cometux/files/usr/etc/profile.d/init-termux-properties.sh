if [ ! -f /data/data/dev.cometix.cometux/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/dev.cometix.cometux/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/dev.cometix.cometux/files/home/.termux
	cp /data/data/dev.cometix.cometux/files/usr/share/examples/termux/termux.properties /data/data/dev.cometix.cometux/files/home/.termux/
fi
