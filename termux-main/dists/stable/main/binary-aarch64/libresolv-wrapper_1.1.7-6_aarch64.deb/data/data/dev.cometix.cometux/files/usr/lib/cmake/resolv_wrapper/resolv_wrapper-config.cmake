set(RESOLV_WRAPPER_LIBRARY /data/data/dev.cometix.cometux/files/usr/lib/libresolv_wrapper.so)
