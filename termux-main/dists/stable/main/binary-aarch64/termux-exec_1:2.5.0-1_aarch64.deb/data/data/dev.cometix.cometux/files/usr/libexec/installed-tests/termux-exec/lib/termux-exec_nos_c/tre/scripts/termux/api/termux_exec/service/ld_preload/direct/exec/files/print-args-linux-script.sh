#!/data/data/dev.cometix.cometux/files/usr/bin/sh

echo "$@"
