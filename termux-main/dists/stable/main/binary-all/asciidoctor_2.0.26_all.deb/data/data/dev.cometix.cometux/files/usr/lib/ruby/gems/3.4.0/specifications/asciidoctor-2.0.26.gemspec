# -*- encoding: utf-8 -*-
# stub: asciidoctor 2.0.26 ruby lib

Gem::Specification.new do |s|
  s.name = "asciidoctor".freeze
  s.version = "2.0.26".freeze

  s.required_rubygems_version = Gem::Requirement.new(">= 0".freeze) if s.respond_to? :required_rubygems_version=
  s.metadata = { "bug_tracker_uri" => "https://github.com/asciidoctor/asciidoctor/issues", "changelog_uri" => "https://github.com/asciidoctor/asciidoctor/blob/HEAD/CHANGELOG.adoc", "funding_uri" => "https://opencollective.com/asciidoctor", "mailing_list_uri" => "https://chat.asciidoctor.org", "source_code_uri" => "https://github.com/asciidoctor/asciidoctor" } if s.respond_to? :metadata=
  s.require_paths = ["lib".freeze]
  s.authors = ["Dan Allen".freeze, "Sarah White".freeze, "Ryan Waldron".freeze, "Jason Porter".freeze, "Nick Hengeveld".freeze, "Jeremy McAnally".freeze]
  s.date = "2018-03-20"
  s.description = "A fast, open source text processor and publishing toolchain for converting AsciiDoc content to HTML 5, DocBook 5, and other formats.".freeze
  s.email = ["dan.j.allen@gmail.com".freeze]
  s.executables = ["asciidoctor".freeze]
  s.files = ["bin/asciidoctor".freeze]
  s.homepage = "https://asciidoctor.org".freeze
  s.licenses = ["MIT".freeze]
  s.rubygems_version = "3.5.22".freeze
  s.summary = "An implementation of the AsciiDoc text processor and publishing toolchain".freeze

  s.installed_by_version = "3.6.7".freeze

  s.specification_version = 4

  s.add_development_dependency(%q<concurrent-ruby>.freeze, ["~> 1.1.0".freeze])
  s.add_development_dependency(%q<cucumber>.freeze, ["~> 3.1.0".freeze])
  s.add_development_dependency(%q<erubi>.freeze, ["~> 1.10.0".freeze])
  s.add_development_dependency(%q<haml>.freeze, ["~> 6.3.0".freeze])
  s.add_development_dependency(%q<minitest>.freeze, ["~> 5.22.0".freeze])
  s.add_development_dependency(%q<nokogiri>.freeze, ["~> 1.13.0".freeze])
  s.add_development_dependency(%q<rake>.freeze, ["~> 12.3.0".freeze])
  s.add_development_dependency(%q<slim>.freeze, ["~> 4.1.0".freeze])
  s.add_development_dependency(%q<tilt>.freeze, ["~> 2.0.0".freeze])
end
